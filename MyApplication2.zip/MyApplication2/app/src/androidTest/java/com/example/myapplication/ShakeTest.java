package com.example.myapplication;

import static org.junit.Assert.*;

public class ShakeTest {

}