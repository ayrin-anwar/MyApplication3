package com.example.myapplication;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class Gyroscope_data extends AppCompatActivity {


    private  DataSnapshot dataSnapshot;
    ListView listview;
    DatabaseReference df;
    ArrayList<String> mUsername = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gyroscope_data);
        df = FirebaseDatabase.getInstance().getReference("Gyroscope");
        listview = (ListView) findViewById(R.id.listview1);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mUsername);


        df.addValueEventListener(new ValueEventListener() {

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUsername.clear();

                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    member s = dataSnapshot1.getValue(member.class);
                    // s1=s1+"Name :"+student.getName().toString()+"\n"+"ID :"+student.getAge()+"\n";
                    mUsername.add("X axis :" + s.getX() + " Y axis " + s.getY() + " Z axis " + s.getZ());

                    //Toast.makeText(getApplicationContext(),"entering",Toast.LENGTH_LONG).show();

                }
                // textView.setText(s1);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }



        });

    }


}



