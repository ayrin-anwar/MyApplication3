package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.widget.TextView;

public class Proximity extends AppCompatActivity {
    private TextView d_tv;
    private Sensor mySensor1;
    private SensorManager SM;
    private ConstraintLayout bg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proximity);
        SM= (SensorManager) getSystemService(SENSOR_SERVICE);

        mySensor1=SM.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        SM.registerListener((SensorEventListener) this,mySensor1,SensorManager.SENSOR_DELAY_NORMAL);


        d_tv=findViewById(R.id.d_tv);
        bg=findViewById(R.id.bg3);
    }
    public void onSensorChanged(SensorEvent event) {

        int x = (int) event.values[0];

        if(x<5)
        {
            Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
            v.vibrate(400);
        }

        d_tv.setText(String.valueOf("D is: "+x));

    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    protected  void onResume()
    {
        super.onResume();
        SM.registerListener((SensorEventListener) this,mySensor1,SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected  void onPause()
    {
        super.onPause();

        SM.unregisterListener((SensorEventListener) this);
    }
}
