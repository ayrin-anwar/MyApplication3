package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class Accelerometer extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    Sensor accelerometer;
    TextView a,b,c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accelerometer);
        sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);
        a=(TextView)findViewById(R.id.x);
        b=(TextView)findViewById(R.id.y);
        c=(TextView)findViewById(R.id.z);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        a.setText(""+(int)sensorEvent.values[0]);
        b.setText(""+(int)sensorEvent.values[1]);
        c.setText(""+(int)sensorEvent.values[2]);
        if((int)sensorEvent.values[1]==9 || (int)sensorEvent.values[1]==-9)
        {
            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
        }

        else
        {
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
